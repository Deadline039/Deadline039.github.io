/**
 * @file    key.c
 * @author  Deadline039
 * @brief   按键扫描
 * @version 0.1
 * @date    2025-01-02
 */

#include <REG52.H>

#include "delay.h"
#include "key.h"

sbit keyA = P3 ^ 2;
sbit keyB = P3 ^ 3;

/**
 * @brief 单按键检测
 *
 * @return 按下的按键
 */
unsigned char key_scan_single(void) {
    if (keyA == 0) {
        delay_ms(10);
        if (keyA == 0) {
            return KEYA_PRESS;
        }
    }

    if (keyB == 0) {
        delay_ms(10);
        if (keyB == 0) {
            return KEYB_PRESS;
        }
    }

    return KEY_NO_PRESS;
}

/**
 * @brief 获取 1 所在的 bit 位, 如 0100 返回 2
 *
 * @param num 数
 * @return 位置
 */
static unsigned char get_bit(unsigned char num) {
    unsigned char i;
    i = 0;

    while (((num & 0x01) == 0) && num > 0) {
        ++i;
        num >>= 1;
    }

    return i;
}

/**
 * @brief 矩阵键盘检测
 *
 * @return 按下的按键
 */
unsigned char key_scan_matrix(void) {
    unsigned char col, row;

    P1 = 0xF;
    if ((P1 & 0xF) == 0xF) {
        return 0;
    }
    delay_ms(10);
    if ((P1 & 0xF) == 0xF) {
        return 0;
    }

    col = get_bit(~(P1 & 0xF));

    P1 = 0xF0;

    if ((P1 & 0xF0) == 0xF0) {
        return 0;
    }

    row = get_bit(~((P1 & 0xF0) >> 4));

    return row * 4 + col + 1;
}
