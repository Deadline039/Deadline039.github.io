/**
 * @file    key.c
 * @author  Deadline039
 * @brief   按键扫描
 * @version 0.1
 * @date    2025-01-02
 */

#define KEY_NO_PRESS 0
#define KEYA_PRESS   1
#define KEYB_PRESS   2


unsigned char key_scan_single(void);
unsigned char key_scan_matrix(void);