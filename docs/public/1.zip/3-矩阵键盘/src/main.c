/**
 * @file    main.c
 * @author  Deadline039
 * @brief   实验3-独立按键/矩阵键盘
 * @version 0.1
 * @date    2024-10-10
 */

#include <REG52.H>

#include "key.h"
#include "seg.h"

/**
 * @brief 主函数
 *
 * @return 退出码
 */
int main(void) {
    unsigned char key;

    while (1) {
        key = key_scan_matrix();
        seg_display_num(key);
    }
}