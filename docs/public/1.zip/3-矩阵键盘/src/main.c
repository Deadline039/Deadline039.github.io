/**
 * @file    main.c
 * @author  Deadline039
 * @brief   实验3-独立按键/矩阵键盘
 * @version 0.1
 * @date    2024-10-10
 */

#include "REG52.H"

const unsigned char seg_table[] = {
    0x3f /* 0 */, 0x06 /* 1 */, 0x5b /* 2 */, 0x4f /* 3 */,
    0x66 /* 4 */, 0x6d /* 5 */, 0x7d /* 6 */, 0x07 /* 7 */,
    0x7f /* 8 */, 0x6f /* 9 */, 0x77 /* A */, 0x7c /* B */,
    0x39 /* C */, 0x5e /* D */, 0x79 /* E */, 0x71 /* F */};

void delay_ms(int ms);
void seg_clear(void);
void seg_display_single(int local, int num);
void seg_display_num(int num);

unsigned char key_scan_single(void);
unsigned char key_scan_matrix(void);

sbit P_HC595_SER = P2 ^ 3;   /* Pin 14 Serial data input */
sbit P_HC595_RCLK = P2 ^ 2;  /* Pin 12 Store latch clock */
sbit P_HC595_SRCLK = P2 ^ 1; /* Pin 11 Shfit data clock */

sbit keyA = P3 ^ 2;
sbit keyB = P3 ^ 3;

#define KEY_NO_PRESS 0
#define KEYA_PRESS   1
#define KEYB_PRESS   2

/**
 * @brief 主函数
 *
 * @return 退出码
 */
int main(void) {
    unsigned char key;

    while (1) {
        key = key_scan_single();
        seg_display_num(key);
    }
}

/**
 * @brief 延时n毫秒
 *
 * @param ms 延时时间
 */
void delay_ms(int ms) {
    int i, j;
    for (i = 0; i < ms; ++i) {
        for (j = 0; j < 150; ++j)
            ;
    }
}

/**
 * @brief 发送数据到74HC595中
 *
 * @param dat 数据
 */
void send_595(unsigned char dat) {
    unsigned char i;

    for (i = 0; i < 8; ++i) {
        dat <<= 1;
        P_HC595_SER = CY;
        P_HC595_SRCLK = 1;
        P_HC595_SRCLK = 0;
    }
}

/**
 * @brief 数码管消隐
 *
 */
void seg_clear(void) {
    send_595(0x00);
    send_595(0x00);

    P_HC595_RCLK = 1;
    P_HC595_RCLK = 0;
}

/**
 * @brief 指定位置显示数字
 *
 * @param local 位置 (1 ~ 8)
 * @param num 数字 (0 ~ 15)
 */
void seg_display_single(int local, int num) {
    send_595(~(1 << (local - 1))); /* 位选 */
    send_595(seg_table[num]);      /* 送段码 */
    P_HC595_RCLK = 1;
    P_HC595_RCLK = 0;
    delay_ms(2);
    seg_clear();
}

/**
 * @brief 数码管显示数
 *
 * @param num 显示的数字(0~9999)
 */
void seg_display_num(int num) {
    unsigned char one_dig, ten_dig, hundred_dig, thousand_dig;

    one_dig = num % 10;
    ten_dig = num / 10 % 10;
    hundred_dig = num / 100 % 10;
    thousand_dig = num / 1000 % 10;

    seg_display_single(8, one_dig);
    seg_display_single(7, ten_dig);
    seg_display_single(6, hundred_dig);
    seg_display_single(5, thousand_dig);
}

/**
 * @brief 单按键检测
 *
 * @return 按下的按键
 */
unsigned char key_scan_single(void) {
    if (keyA == 0) {
        delay_ms(10);
        if (keyA == 0) {
            return KEYA_PRESS;
        }
    }

    if (keyB == 0) {
        delay_ms(10);
        if (keyB == 0) {
            return KEYB_PRESS;
        }
    }

    return KEY_NO_PRESS;
}

/**
 * @brief 获取 1 所在的 bit 位, 如 0100 返回 2
 *
 * @param num 数
 * @return 位置
 */
static unsigned char get_bit(unsigned char num) {
    unsigned char i;
    i = 0;

    while (((num & 0x01) == 0) && num > 0) {
        ++i;
        num >>= 1;
    }

    return i;
}

/**
 * @brief 矩阵键盘检测
 *
 * @return 按下的按键
 */
unsigned char key_scan_matrix(void) {
    unsigned char col, row;

    P1 = 0xF;
    if ((P1 & 0xF) == 0xF) {
        return 0;
    }
    delay_ms(10);
    if ((P1 & 0xF) == 0xF) {
        return 0;
    }

    col = get_bit(~(P1 & 0xF));

    P1 = 0xF0;

    if ((P1 & 0xF0) == 0xF0) {
        return 0;
    }

    row = get_bit(~((P1 & 0xF0) >> 4));

    return row * 4 + col + 1;
}
