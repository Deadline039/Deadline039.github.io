/**
 * @file    main.c
 * @author  Deadline039
 * @brief   实验4-IO扩展实验
 * @version 0.1
 * @date    2024-10-10
 */

#include "ABSACC.H"
#include "REG52.H"

#define PA  XBYTE[0xff70]
#define PB  XBYTE[0xff71]
#define PC  XBYTE[0xff72]
#define CTR XBYTE[0xff73]

void delay_ms(int ms);

/**
 * @brief IO扩展流水灯实验
 *
 * @param delay_time 延时时间(毫秒)
 */
void io_expand_demo(int delay_time) {
    PA = ~(1 << 2);
    delay_ms(delay_time);
    PA = ~(1 << 1);
    delay_ms(delay_time);
    PA = ~(1 << 0);
    delay_ms(delay_time);
    PA = 0xFF; /* 关闭 A 灯 */

    PC = ~(1 << 0);
    delay_ms(delay_time);
    PC = ~(1 << 7);
    delay_ms(delay_time);
    PC = 0xFF; /* 关闭C灯 */

    PB = 0x7F;
    PB = ~(1 << 7);
    delay_ms(delay_time);
    PB = ~(1 << 6);
    delay_ms(delay_time);
    PB = ~(1 << 5);
    delay_ms(delay_time);
    PB = 0xFF; /* 关闭B灯 */
}

/**
 * @brief 主函数
 *
 * @return 退出码
 */
int main(void) {
    CTR = 0x80;

    /* 关闭 A B C 灯 */
    PA = 0xFF;
    PB = 0xFF;
    PC = 0xFF;

    while (1) {
        io_expand_demo(300);
    }
}

/**
 * @brief 延时n毫秒
 *
 * @param ms 延时时间
 */
void delay_ms(int ms) {
    int i, j;
    for (i = 0; i < ms; ++i) {
        for (j = 0; j < 150; ++j)
            ;
    }
}
