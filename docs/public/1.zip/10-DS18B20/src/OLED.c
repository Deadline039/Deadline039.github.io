/**
  ******************************************************************************
  * @file    OLED.c
  * @author  LiuQ
  * @version A001
  * @date    2017/11/04
  * @brief   6线OLED屏幕的SPI驱动
  ******************************************************************************
  * @attention
  *			驱动测试平台：STC15W4K16S4 DIP28 自制单片机最小系统
  *			IO对应关系
  *			|	1	  |	GND		|	GND		|
  *			|	2	  |	VCC		|	3.3V	|
  *			|	3	  |	SCL		|	P0.0	|
  *			|	4	  |	SDA		|	P0.1	|
  *			|	5	  |	RES		|	P0.2	|
  *			|	6	  |	DC		|	P0.3	|
  *	    	|	7	  |	CS		|	GND  	|***********************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "OLED.h"
#include "OLEDFONT.h"
#include "DELAY.h"

/**
  * @brief  OLED初始化程序
  * @param  无
  * @retval None
  */
void OLED_Init(void)
{
  //OLED_GPIOConfig();
  OLED_REGConfig();
  OLED_Clear();
}


/**
  * @brief  OLED控制寄存器初始化程序
  * @param  无
  * @retval None
  */
void OLED_REGConfig(void)
{
	delay_ms(100);
  /* 使能OLED复位（低电平有效）,复位时间需要100ms */
  OLED_GPIO &=~ OLED_RES;
  delay_ms(100);
  /* 释放复位信号 */
  OLED_GPIO |= OLED_RES;
//  delay_ms(1);
  /* display off */
  OLED_WR_Byte(0xAE,OLED_CMD);
  /* set display clock divide ratio */
  OLED_WR_Byte(0xD5,OLED_CMD);
  /* 100 Frames/sec */
  OLED_WR_Byte(0x80,OLED_CMD);
  /* multiplex ratio */
  OLED_WR_Byte(0xA8,OLED_CMD);
  /* duty = 1/64 */
  OLED_WR_Byte(0x3F,OLED_CMD);
  /* set display offset */
  OLED_WR_Byte(0xD3,OLED_CMD);
  /* not offset */
  OLED_WR_Byte(0x00,OLED_CMD);
  /* set display start line */
  OLED_WR_Byte(0x40,OLED_CMD);
  /* set segment remap */
  OLED_WR_Byte(0xA1,OLED_CMD);
  /* Com scan direction */
  OLED_WR_Byte(0xC8,OLED_CMD);
  /* set COM Pins Hardware Config */
  OLED_WR_Byte(0xDA,OLED_CMD);
  /* Disable COM Left/Right remap */
  OLED_WR_Byte(0x12,OLED_CMD);
  /* contract control */
  OLED_WR_Byte(0x81,OLED_CMD);
  /* 128 */
  OLED_WR_Byte(0x66,OLED_CMD);
  /* set pre-charge period */
  OLED_WR_Byte(0xD9,OLED_CMD);
  /* pre-Charge 15 Clock & Discharge as 1 Clock */
  OLED_WR_Byte(0xF1,OLED_CMD);
   /* Set VCOMH Deselect Level */
  OLED_WR_Byte(0xDB,OLED_CMD);
  /* ~0.83 x VCC */
  OLED_WR_Byte(0x30,OLED_CMD);
  /* set entire display On/off */
  OLED_WR_Byte(0xA4,OLED_CMD);
  /* normal / reverse */
  OLED_WR_Byte(0xA6,OLED_CMD);
  /* set Charge Pump */
  OLED_WR_Byte(0x8D,OLED_CMD);
  /* disable */
  OLED_WR_Byte(0x14,OLED_CMD);
  /* set display on */
  OLED_WR_Byte(0xAF,OLED_CMD);
}
/**
  * @brief  OLED清屏函数
  * @param  无
  * @retval None
  */
void OLED_Clear(void)
{
  uint8_t i,j = 0;
  for (i = 0; i < 8; ++i)
  {
    /* 设置页地址（0~7） */
    OLED_WR_Byte(0xb0 + i, OLED_CMD);
    /* 设置显示位置--列低地址 */
    OLED_WR_Byte(0x00,OLED_CMD);
    /* 设置显示位置--列高地址 */
    OLED_WR_Byte(0x10,OLED_CMD);
    for (j = 0; j < 128; ++j)
    {
      /* 写0清除显示 */
      OLED_WR_Byte(0x00,OLED_DATA);
    }
  }
}

/**
  * @brief  OLED写数据/命令函数
  * @param  dat:串行数据
  * @param  cmd:数据0/命令1
  * @retval None
  */
void OLED_WR_Byte(uint8_t dat,uint8_t cmd)
{
  uint8_t i = 0;
  if (cmd)
  {
    /* DC = 1 表示写数据 */
    OLED_GPIO |= OLED_DC;
  }
  else
  {
    /* DC = 0 表示写命令 */
    OLED_GPIO &=~ OLED_DC;
  }
  for (i = 0; i < 8; ++i)
  {
    OLED_GPIO &=~ OLED_SCL;
		/* 高位在前 */
    if(dat & (1<<(7-i)))
    {
      OLED_GPIO |= OLED_SDA;
    }
    else
    {
      OLED_GPIO &=~ OLED_SDA;
    }
    OLED_GPIO |= OLED_SCL;
  }
  /* 释放OLED_DC */
  OLED_GPIO |= OLED_DC;
}

/**
  * @brief  OLED字符串显示函数
  * @param  x:起始行坐标 0 - 127
  * @param  y:起始列坐标 0 - 6
  * @param  *p:字符串起始地址
  * @retval None
  */
void OLED_ShowString(uint8_t x,uint8_t y,uint8_t *p)
{
  uint8_t x_pos = x;
  uint8_t y_pos = y;
  uint8_t i = 0;
  while (p[i] != '\0')
  {
    OLED_ShowChar(x_pos,y_pos,p[i]);
    x_pos += 8;
    if(x_pos > 120)
    {
      x_pos = 0;
      y_pos += 2;
    }
    i++;
  }
}

/**
  * @brief  OLED字符显示函数
  * @param  x:起始行坐标 0 - 127
  * @param  y:起始列坐标 0 - 6
  * @param  p:字符索引
  * @retval None
  */
void OLED_ShowChar(uint8_t x,uint8_t y,uint8_t p)
{
  uint8_t x_pos = x;
  uint8_t y_pos = y;
  uint8_t i = 0;
  uint8_t n = p - ' ';
  OLED_Set_Pos(x_pos,y_pos);
  for (i = 0; i < 8; ++i)
  {
    OLED_WR_Byte(F8X16[n*16 + i],OLED_DATA);
  }
  OLED_Set_Pos(x_pos,y_pos+1);
  for (i = 0; i < 8; ++i)
  {
    OLED_WR_Byte(F8X16[n*16 + i + 8],OLED_DATA);
  }
}

/**
  * @brief  OLED显示地址设置
  * @param  x:起始行坐标 0 - 127
  * @param  y:页地址 0 - 7
  * @retval None
  */
void OLED_Set_Pos(uint8_t x,uint8_t y)
{
  /* Set Page Start Address for Page Addressing Mode */
  OLED_WR_Byte(0xb0 + y,OLED_CMD);
  /* Set highter nibble of the column for Page Addressing Mode */
  OLED_WR_Byte((x & 0xf0) >> 4 | 0x10,OLED_CMD);
  /* Set lower nibble of the column for Page Addressing Mode */
  OLED_WR_Byte((x & 0x0f),OLED_CMD);
}

void display_hz(uint8_t X,uint8_t Y,uint8_t n)
{	 
	uint8_t m;
	OLED_WR_Byte(0xb7-(Y<<1),OLED_CMD);//设置页地址7~0  因为屏幕也显存相反  故从第七页开始写   又因为用了16X16点阵字符  故每个字符会用到两个也 故Y<<1.
	if(X%2)
	 OLED_WR_Byte(0x08,OLED_CMD);
	else
	 OLED_WR_Byte(0x00,OLED_CMD);
     OLED_WR_Byte(0x10+(X>>1),OLED_CMD);
	for(m=0;m<=31;m+=2)
 OLED_WR_Byte(*(hanzi2_1616[n]+m),OLED_DATA);                    
  OLED_WR_Byte(0xb7-(Y<<1)-1,OLED_CMD);

	if(X%2)
	 OLED_WR_Byte(0x08,OLED_CMD);
	else
	 OLED_WR_Byte(0x00,OLED_CMD);
OLED_WR_Byte(0x10+(X>>1),OLED_CMD);
	for(m=1;m<=31;m+=2)
	 OLED_WR_Byte(*(hanzi2_1616[n]+m),OLED_DATA);  
}  
