/**
  ******************************************************************************
  * @file    OLED.h
  * @author  LiuQ
  * @version A001
  * @date    2017/11/04
  * @brief   6线OLED屏幕的SPI驱动
  *********************************************************
  *			
  *			|	1	|	GND		|	GND		|
  *			|	2	|	VCC		|	3.3V	|
  *			|	3	|	SCL		|	P0.0	|
  *			|	4	|	SDA		|	P0.1	|
  *			|	5	|	RES		|	P0.2	|
  *			|	6	|	DC		|	P0.3	|
  *			
  *			
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __OLED_H
#define __OLED_H

/* Includes ------------------------------------------------------------------*/
#include "reg52.h"


/* TypeDefs ------------------------------------------------------------------*/
typedef unsigned char uint8_t;
typedef unsigned int uint16_t;
typedef unsigned long uint32_t;

/** @defgroup OLED_IO_Group 
  * @{
  */
#define OLED_SCL 	(uint8_t)(1<<4)    //0000 0001
#define OLED_SDA 	(uint8_t)(1<<5)    //0000 0010 
#define OLED_RES 	(uint8_t)(1<<6)    //0000 0100
#define OLED_DC 	(uint8_t)(1<<7)    //0000 1000
#define OLED_GPIO 	P2

/** @defgroup OLED_DAT/CMD 
  * @{
  */
#define OLED_CMD 	0
#define OLED_DATA	1


/** @defgroup OLED_Exported_Functions
  * @{*/
void OLED_Init(void);
void OLED_ShowString(uint8_t x,uint8_t y,uint8_t *p);
void OLED_REGConfig(void);
void OLED_Clear(void);
void OLED_WR_Byte(uint8_t dat,uint8_t cmd);
void OLED_ShowString(uint8_t x,uint8_t y,uint8_t *p);
void OLED_ShowChar(uint8_t x,uint8_t y,uint8_t p);
void OLED_Set_Pos(uint8_t x,uint8_t y);
void display_hz(uint8_t X,uint8_t Y,uint8_t n);

#endif

