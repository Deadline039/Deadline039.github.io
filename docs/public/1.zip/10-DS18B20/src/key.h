/**
 * @file    key.h
 * @author  Deadline039
 * @brief   按键
 * @version 0.1
 * @date    2024-12-05
 */

#define KEY_NO_PRESS 0
#define KEYA_PRESS   1
#define KEYB_PRESS   2

unsigned char key_scan_single(void);
unsigned char key_scan_matrix(void);