/**
 * @file    delay.c
 * @author  Deadline039
 * @brief   延时
 * @version 0.1
 * @date    2024-12-05
 */

#include "delay.h"

/**
 * @brief 延时n毫秒
 *
 * @param ms 延时时间
 */
void delay_ms(int ms) {
    int i, j;
    for (i = 0; i < ms; ++i) {
        for (j = 0; j < 150; ++j)
            ;
    }
}
