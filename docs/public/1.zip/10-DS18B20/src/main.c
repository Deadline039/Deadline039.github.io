/**
  ******************************************************************************
  *			|	1	  |	GND		|	GND		|
  *			|	2	  |	VCC		|	3.3V	|
  *			|	3	  |	SCL		|	P0.0	|
  *			|	4	  |	SDA		|	P0.1	|
  *			|	5	  |	RES		|	P0.2	|
  *			|	6	  |	DC		|	P0.3	|
  *
  ******************************************************************************
   我尽然无话可说！	 */
/* Includes ------------------------------------------------------------------*/
#include "DELAY.h"
#include "OLED.h"
#include "temp.h"
#include "reg52.h"
#include <STDIO.H>

char str[30];
void main(void) {
    float temp;
    OLED_Init();
    
    while (1) {
        temp = Ds18b20ReadTemp();
        sprintf(str, "temp: %.2f C", temp);
        OLED_ShowString(0, 0, str);
    }
}
