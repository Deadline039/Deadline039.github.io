/**
 * @file    delay.h
 * @author  Deadline039
 * @brief   延时
 * @version 0.1
 * @date    2024-12-05
 */

#ifndef __DELAY_H
#define __DELAY_H

void delay_ms(int ms);

#endif /* __DELAY_H */
