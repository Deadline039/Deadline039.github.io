#ifndef __TEMP_H_
#define __TEMP_H_

//--声明全局函数--//
void Ds18b20ChangTemp();
void Ds18b20ReadTempCom();
float Ds18b20ReadTemp();

#endif
