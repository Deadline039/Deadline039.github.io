/**
 * @file    seg.c
 * @author  Deadline039
 * @brief   数码管
 * @version 0.1
 * @date    2024-10-10
 */

#include "seg.h"
#include "REG52.H"
#include "delay.h"

const unsigned char seg_table[] = {
    0x3f /* 0 */, 0x06 /* 1 */, 0x5b /* 2 */, 0x4f /* 3 */, 0x66 /* 4 */,
    0x6d /* 5 */, 0x7d /* 6 */, 0x07 /* 7 */, 0x7f /* 8 */, 0x6f /* 9 */,
    0x77 /* A */, 0x7c /* B */, 0x39 /* C */, 0x5e /* D */, 0x79 /* E */,
    0x71 /* F */, 0x40 /* - */};

sbit P_HC595_SER = P2 ^ 3;   /* Pin 14 Serial data input */
sbit P_HC595_RCLK = P2 ^ 2;  /* Pin 12 Store latch clock */
sbit P_HC595_SRCLK = P2 ^ 1; /* Pin 11 Shfit data clock */

/**
 * @brief 发送数据到74HC595中
 *
 * @param dat 数据
 */
void send_595(unsigned char dat) {
    unsigned char i;

    for (i = 0; i < 8; ++i) {
        dat <<= 1;
        P_HC595_SER = CY;
        P_HC595_SRCLK = 1;
        P_HC595_SRCLK = 0;
    }
}

/**
 * @brief 数码管消隐
 *
 */
void seg_clear(void) {
    send_595(0x00);
    send_595(0x00);

    P_HC595_RCLK = 1;
    P_HC595_RCLK = 0;
}

/**
 * @brief 指定位置显示数字
 *
 * @param local 位置 (1 ~ 8)
 * @param num 数字 (0 ~ 15)
 */
void seg_display_single(int local, int num) {
    send_595(~(1 << (local - 1))); /* 位选 */
    send_595(seg_table[num]);      /* 送段码 */
    P_HC595_RCLK = 1;
    P_HC595_RCLK = 0;
    delay_ms(1);
    seg_clear();
}

/**
 * @brief 数码管显示数
 *
 * @param num 显示的数字(0~9999)
 */
void seg_display_num(int num) {
    unsigned char one_dig, ten_dig, hundred_dig, thousand_dig;

    one_dig = num % 10;
    ten_dig = num / 10 % 10;
    hundred_dig = num / 100 % 10;
    thousand_dig = num / 1000 % 10;

    seg_display_single(8, one_dig);
    seg_display_single(7, ten_dig);
    seg_display_single(6, hundred_dig);
    seg_display_single(5, thousand_dig);
}
