/**
 * @file    main.c
 * @author  Deadline039
 * @brief   实验2-数码管
 * @version 0.1
 * @date    2024-10-10
 */

#include "REG52.H"
#include "delay.h"
#include "key.h"
#include "seg.h"

unsigned char key_scan_single(void);
void timer_init(void);

signed long total_seconds = 0;

int year, month, day;
unsigned hour, min, sec;

#define START_YEAR  1970
#define START_MONTH 1
#define START_DAY   1
long total_days = 0; /* 从 1970 年 1 月 1 日到现在的天数 */

void show_time(void);
void show_date(void);

/**
 * @brief 主函数
 *
 * @return 退出码
 */
int main(void) {
    unsigned char show_date_flag = 0;
    timer_init();

    while (1) {
        if (key_scan_single() == KEYA_PRESS) {
            show_date_flag = !show_date_flag;
        }
        if (show_date_flag) {
            show_date();
        } else {
            show_time();
        }
    }
}

/**
 * @brief 数码管显示时间
 *
 */
void show_time(void) {
    seg_display_single(1, hour / 10);
    seg_display_single(2, hour % 10);
    seg_display_single(3, 16);
    seg_display_single(4, min / 10);
    seg_display_single(5, min % 10);
    seg_display_single(6, 16);
    seg_display_single(7, sec / 10);
    seg_display_single(8, sec % 10);
}

unsigned char get_month_day(unsigned int year, unsigned char month) {
    const unsigned char month_day_table[12] = {31, 28, 31, 30, 31, 30,
                                               31, 31, 30, 31, 30, 31};
    if (month == 2) {
        if (year % 4 == 0 && year % 100 != 0 || year % 400 == 0) {
            return 29;
        } else {
            return 28;
        }
    }

    return month_day_table[month - 1];
}

/**
 * @brief 数码管显示日期
 *
 */
void show_date(void) {

    unsigned char seg_num[8];
    unsigned char i;

    int number = total_seconds;

    number += START_DAY;
    day = number;

    if (day >= 28) {
        for (; number > 28; month++) {
            if (number > 27) {
                number = number - get_month_day(year, month);
                if (month > 11) {
                    year++;
                    month = 0;
                }

                day = number;
            }
        }
    }

    seg_num[0] = year / 1000 % 10;
    seg_num[1] = year / 100 % 10;
    seg_num[2] = year / 10 % 10;
    seg_num[3] = year / 1 % 10;
    seg_num[4] = month / 10 % 10;
    seg_num[5] = month / 1 % 10;
    seg_num[6] = day / 10 % 10;
    seg_num[7] = day / 1 % 10;
    for (i = 0; i < 8; i++) {
        seg_display_single(i, seg_num[i]);
    }
}

/**
 * @brief 定时器初始化
 *
 */
void timer_init(void) {
    TMOD = 0x11;
    ET1 = 1;
    ET0 = 0;
    TH1 = (0xFF - 50000U) >> 8;
    TL1 = (0xFF - 50000U) & 0xFF; /* 50 ms */
    TR1 = 1;
    TR0 = 1;
    EA = 1;
}

/**
 * @brief 定时器中断服务函数
 *
 */
void timer_irq(void) interrupt 3 using 0 {
    static unsigned char times = 0;
    TH1 = (0xFF - 50000U) >> 8;
    TL1 = (0xFF - 50000U) & 0xFF; /* 50 ms */

    if (times == 20) {
        ++total_seconds;
        times = 0;

        hour = total_seconds / 3600;
        min = total_seconds / 60 % 60;
        sec = total_seconds % 60;
        if (hour >= 24) {
            total_seconds = 0;
            ++total_days;
        }
    }

    ++times;
}