/**
 * @file    exti.h
 * @author  Deadline039
 * @brief   外部中断
 * @version 0.1
 * @date    2024-12-02
 */

#ifndef __EXTI_H
#define __EXTI_H

typedef void (*exti_callback_t)(void);

#define NULL (void *)0

void exti_init(void);
void exti_register_callback(unsigned char key_number, exti_callback_t callback);
void exti_unregister_callback(unsigned char key_number);

#endif /* __EXTI_H */
