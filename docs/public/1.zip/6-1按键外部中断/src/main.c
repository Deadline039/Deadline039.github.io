/**
 * @file    main.c
 * @author  Deadline039
 * @brief   实验2-数码管
 * @version 0.1
 * @date    2024-10-10
 */

#include "REG52.H"

#include "exti.h"
#include "key.h"
#include "seg.h"

unsigned int number;

static void sw1_callback(void);
static void sw2_callback(void);

/**
 * @brief 主函数
 *
 * @return 退出码
 */
int main(void) {
    exti_init();
    exti_register_callback(0, sw1_callback);
    exti_register_callback(1, sw2_callback);

    while (1) {
        seg_display_num(number);
    }
}

/**
 * @brief 按键 1 回调函数
 *
 */
static void sw1_callback(void) {
    ++number;
    if (number > 9999) {
        number = 0;
    }
}

/**
 * @brief 按键 2 回调函数
 *
 */
static void sw2_callback(void) {
    --number;
    if (number > 9999) {
        number = 9999;
    }
}