/**
 * @file    exti.c
 * @author  Deadline039
 * @brief   外部中断初始化
 * @version 0.1
 * @date    2024-12-02
 */

#include <REG52.H>

#include "exti.h"

static exti_callback_t s_key_callback[2];

/**
 * @brief 外部中断初始化
 *
 */
void exti_init(void) {
    IT0 = 1;
    IT1 = 1;

    EX0 = 1;
    EX1 = 1;
    EA = 1;
}

/**
 * @brief 注册中断回调函数
 *
 * @param key_number 按键中断号, 0 或者 1
 * @param callback 回调函数
 */
void exti_register_callback(unsigned char key_number,
                            exti_callback_t callback) {
    if (key_number > 1) {
        return;
    }

    s_key_callback[key_number] = callback;
}

/**
 * @brief 取消注册中断回调函数
 *
 * @param key_number 按键中断号, 0 或者 1
 */
void exti_unregister_callback(unsigned char key_number) {
    if (key_number > 1) {
        return;
    }
    s_key_callback[key_number] = NULL;
}

/**
 * @brief 外部中断0
 *
 */
void exit0(void) interrupt 0 {
    s_key_callback[0]();
}

/**
 * @brief 外部中断1
 *
 */
void exit1(void) interrupt 2 {
    s_key_callback[1]();
}