/**
 * @file    main.c
 * @author  Deadline039
 * @brief   实验1-流水灯
 * @version 0.1
 * @date    2024-10-10
 */

#include "REG52.H"

/**
 * @brief 延时n毫秒
 *
 * @param ms 延时时间
 */
void delay_ms(int ms) {
    int i, j;
    for (i = 0; i < ms; ++i) {
        for (j = 0; j < 150; ++j)
            ;
    }
}

/**
 * @brief 主函数
 *
 * @return 退出码
 */
int main(void) {
    int i;

    P1 = 0xFF;
    for (i = 0; i < 8; ++i) {
        P1 = ~(1 << i);
        delay_ms(500);
    }
}