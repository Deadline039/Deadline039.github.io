/**
 * @file    seg.h
 * @author  Deadline039
 * @brief   数码管
 * @version 0.1
 * @date    2024-12-31
 */

#ifndef __SEG_H
#define __SEG_H

void seg_clear(void);
void seg_display_single(int local, int num);
void seg_display_num(int num);

#endif /* __SEG_H */
