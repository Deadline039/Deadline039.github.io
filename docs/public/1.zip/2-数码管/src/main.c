/**
 * @file    main.c
 * @author  Deadline039
 * @brief   实验2-数码管
 * @version 0.1
 * @date    2024-10-10
 */

#include "REG52.H"

#include "seg.h"

/**
 * @brief 主函数
 *
 * @return 退出码
 */
int main(void) {
    unsigned int i;
    unsigned int j;

    while (1) {
        for (i = 1; i <= 8;++i){
            seg_display_single(i, i);
        }
    }
}