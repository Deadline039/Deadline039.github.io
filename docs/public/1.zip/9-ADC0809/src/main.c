/**
  ******************************************************************************
  *			|	1	  |	GND		|	GND		|
  *			|	2	  |	VCC		|	3.3V	|
  *			|	3	  |	SCL		|	P0.0	|
  *			|	4	  |	SDA		|	P0.1	|
  *			|	5	  |	RES		|	P0.2	|
  *			|	6	  |	DC		|	P0.3	|
  *
  ******************************************************************************
   我尽然无话可说！	 */
/* Includes ------------------------------------------------------------------*/

#include "DELAY.h"
#include "OLED.h"
#include "STDIO.H"
#include "adc0809.h"
#include "reg52.h"
char str[20];

int main(void) {
    int adc_value;

    OLED_Init();
    while (1) {
        adc_value = adc_get_result();
        sprintf(str, "raw=%3d", adc_value);
        OLED_ShowString(0, 0, str);
        sprintf(str, "volatge=%.2fV", (float)(adc_value * 0.0196f));
        OLED_ShowString(0, 2, str);
    }
}
