/**
 * @file    adc0809.c
 * @author  Deadline039
 * @brief   ADC0809 驱动程序
 * @version 0.1
 * @date    2024-12-26
 */

#include "adc0809.h"
#include "delay.h"
#include <ABSACC.H>
#include <INTRINS.H>

#define ADC0809 XBYTE[0xFFA0]

/**
 * @brief 获取ADC结果
 *
 * @return ADC采集结果
 */
int adc_get_result(void) {
    ADC0809 = 0xFF;
    delay_ms(2);
    return ADC0809;
}