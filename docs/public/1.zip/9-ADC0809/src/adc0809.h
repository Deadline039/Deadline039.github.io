/**
 * @file    adc0809.h
 * @author  Deadline039
 * @brief   ADC0809驱动程序
 * @version 0.1
 * @date    2024-12-26
 */

#ifndef __ADC0809_H
#define __ADC0809_H

int adc_get_result(void);

#endif /* __ADC0809_H */
