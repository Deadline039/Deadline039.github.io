/**
 * @file    main.c
 * @author  Deadline039
 * @brief   实验2-数码管
 * @version 0.1
 * @date    2024-10-10
 */

#include "REG52.H"

const unsigned char seg_table[] = {
    0x3f /* 0 */, 0x06 /* 1 */, 0x5b /* 2 */, 0x4f /* 3 */, 0x66 /* 4 */,
    0x6d /* 5 */, 0x7d /* 6 */, 0x07 /* 7 */, 0x7f /* 8 */, 0x6f /* 9 */,
    0x77 /* A */, 0x7c /* B */, 0x39 /* C */, 0x5e /* D */, 0x79 /* E */,
    0x71 /* F */, 0x40 /* - */, 0x00 /*   */};

sbit P_HC595_SER = P2 ^ 3;   /* Pin 14 Serial data input */
sbit P_HC595_RCLK = P2 ^ 2;  /* Pin 12 Store latch clock */
sbit P_HC595_SRCLK = P2 ^ 1; /* Pin 11 Shfit data clock */

sbit keyA = P3 ^ 2;
sbit keyB = P3 ^ 3;
#define KEYA_PRESS   1
#define KEYB_PRESS   2
#define NO_KEY_PRESS 0

void delay_ms(int ms);
void seg_clear(void);
void seg_display_single(int local, int num);
void seg_display_num(int num);

void timer_init(void);

unsigned long total_second = 65;

unsigned char key_scan(void);
void set_time(void);
void show_time(unsigned long now_time);

/* 正在倒计时标志 */
unsigned char timing_flag = 0;

/**
 * @brief 主函数
 *
 * @return 退出码
 */
int main(void) {
    unsigned char key;
    timer_init();
    while (1) {
        key = key_scan();
        switch (key) {
            case KEYA_PRESS: {
                timing_flag = !timing_flag;
            } break;

            case KEYB_PRESS: {
                set_time();
            } break;

            default:
                break;
        }
        show_time(total_second);
    }
}

/**
 * @brief 按键扫描
 *
 * @return 按下的按键
 */
unsigned char key_scan(void) {
    static unsigned char key_up = 1;

    if (key_up && (keyA == 0 || keyB == 0)) {
        delay_ms(10);
        key_up = 0;
        if (keyA == 0) {
            return KEYA_PRESS;
        } else if (keyB == 0) {
            return KEYB_PRESS;
        }
    } else if (keyA == 1 && keyB == 1) {
        key_up = 1;
    }

    return NO_KEY_PRESS;
}

/* 分十位, 个位; 秒十位, 个位对应的数码管位置 */
static const unsigned char bit_table[4] = {4, 5, 7, 8};
unsigned long blink_times;

/**
 * @brief 设置倒计时时间
 *
 */
void set_time(void) {

    /* 按下的按键 */
    unsigned char key;
    /* 当前调整的数码管位 */
    unsigned char modify_bit = 0;
    /* 转换后的分秒 */
    unsigned char min, sec;
    /* 每一位的数字 */
    unsigned char bit_num[4];
    unsigned char i;

    /* 暂停计时 */
    timing_flag = 0;

    /* 当前时间每一位显示的内容 */
    min = total_second / 60;
    bit_num[0] = min / 10;
    bit_num[1] = min % 10;

    sec = total_second % 60;
    bit_num[2] = sec / 10;
    bit_num[3] = sec % 10;

    while (1) {
        key = key_scan();
        if (key == KEYA_PRESS) {
            ++bit_num[modify_bit];
            if (modify_bit == 2) {
                /* 对于秒十位, 0 ~ 5 循环 */
                bit_num[modify_bit] %= 6;
            } else {
                /* 其他位, 0 ~ 10 循环 */
                bit_num[modify_bit] %= 10;
            }
        } else if (key == KEYB_PRESS) {
            ++modify_bit;
            if (modify_bit > 3) {
                break;
            }
        }

        /* 显示其他数字 */
        for (i = 0; i < 4; ++i) {
            if (i == modify_bit) {
                continue;
            }
            seg_display_single(bit_table[i], bit_num[i]);
        }
        /* 显示分, 秒中间的杠 */
        seg_display_single(6, 16);
        /* 闪烁显示当前调整的位 */
        if (blink_times < 100) {
            seg_display_single(bit_table[modify_bit], bit_num[modify_bit]);
        } else if (blink_times < 200) {
            seg_display_single(bit_table[modify_bit], 17);
        } else {
            blink_times = 0;
        }
        ++blink_times;
    }

    min = bit_num[0] * 10 + bit_num[1];
    sec = bit_num[2] * 10 + bit_num[3];
    total_second = min * 60 + sec;
    timing_flag = 1;
}

/**
 * @brief 数码管显示时间
 *
 * @param now_time 现在的时间秒数
 */
void show_time(unsigned long now_time) {
    unsigned min, sec;

    min = now_time / 60;
    sec = now_time % 60;
    seg_display_single(4, min / 10);
    seg_display_single(5, min % 10);
    seg_display_single(6, 16);
    seg_display_single(7, sec / 10);
    seg_display_single(8, sec % 10);
}

/**
 * @brief 定时器初始化
 *
 */
void timer_init(void) {
    TMOD = 0x11;
    ET1 = 1;
    ET0 = 0;
    TH1 = (0xFF - 50000U) >> 8;
    TL1 = (0xFF - 50000U) & 0xFF; /* 50 ms */
    TR1 = 1;
    TR0 = 1;
    EA = 1;
}

/**
 * @brief 定时器中断服务函数
 *
 */
void timer_irq(void) interrupt 3 using 0 {
    static unsigned char times = 0;
    TH1 = (0xFF - 50000U) >> 8;
    TL1 = (0xFF - 50000U) & 0xFF; /* 50 ms */

    if (times == 20) {
        if (timing_flag) {
            --total_second;
            timing_flag = (total_second == 0) ? 0 : 1;
        }
        times = 0;
    }

    ++times;
    }

/**
 * @brief 延时n毫秒
 *
 * @param ms 延时时间
 */
void delay_ms(int ms) {
    int i, j;
    for (i = 0; i < ms; ++i) {
        for (j = 0; j < 150; ++j)
            ;
    }
}

/**
 * @brief 发送数据到74HC595中
 *
 * @param dat 数据
 */
void send_595(unsigned char dat) {
    unsigned char i;

    for (i = 0; i < 8; ++i) {
        dat <<= 1;
        P_HC595_SER = CY;
        P_HC595_SRCLK = 1;
        P_HC595_SRCLK = 0;
    }
}

/**
 * @brief 数码管消隐
 *
 */
void seg_clear(void) {
    send_595(0x00);
    send_595(0x00);

    P_HC595_RCLK = 1;
    P_HC595_RCLK = 0;
}

/**
 * @brief 指定位置显示数字
 *
 * @param local 位置 (1 ~ 8)
 * @param num 数字 (0 ~ 15)
 */
void seg_display_single(int local, int num) {
    send_595(~(1 << (local - 1))); /* 位选 */
    send_595(seg_table[num]);      /* 送段码 */
    P_HC595_RCLK = 1;
    P_HC595_RCLK = 0;
    delay_ms(1);
    seg_clear();
}

/**
 * @brief 数码管显示数
 *
 * @param num 显示的数字(0~9999)
 */
void seg_display_num(int num) {
    unsigned char one_dig, ten_dig, hundred_dig, thousand_dig;

    one_dig = num % 10;
    ten_dig = num / 10 % 10;
    hundred_dig = num / 100 % 10;
    thousand_dig = num / 1000 % 10;

    seg_display_single(8, one_dig);
    seg_display_single(7, ten_dig);
    seg_display_single(6, hundred_dig);
    seg_display_single(5, thousand_dig);
}
