/**
  ******************************************************************************
  *			|	1	  |	GND		|	GND		|
  *			|	2	  |	VCC		|	3.3V	|
  *			|	3	  |	SCL		|	P0.0	|
  *			|	4	  |	SDA		|	P0.1	|
  *			|	5	  |	RES		|	P0.2	|
  *			|	6	  |	DC		|	P0.3	|
  *
  ******************************************************************************
   我尽然无话可说！	 */
/* Includes ------------------------------------------------------------------*/
#include "DELAY.h"
#include "OLED.h"
#include "reg52.h"

void main(void) {
    int i;
    OLED_Init();
    OLED_ShowString(0, 0, "Hello it a Bad!^.^");
    OLED_ShowString(32, 6, "2023-12-01");
    delay_ms(2000);
    OLED_Clear();
    OLED_ShowString(126, 4, "^.^2023-12-01*.*"); //(0<x<128,,0<y<?)
    while (1) {
        for (i = 0; i < 13; i++) {
            display_hz(i * 2, 3, i); //(行0<x<32,列0<y<4)
            delay_ms(400);
        }

        for (i = 13; i > 0; i--) {
            display_hz(i * 2, 2, i); //(行0<x<32,列0<y<4)
            delay_ms(400);
        }
    }
}
