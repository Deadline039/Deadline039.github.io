/**
 * @file    main.c
 * @author  Deadline039
 * @brief   实验2-数码管
 * @version 0.1
 * @date    2024-10-10
 */

#include "REG52.H"
#include <STDIO.H>

void delay_ms(int ms);

void serial_init(void) {
    SCON = 0x50;
    PCON = 0x00;
    TMOD = 0x20; /* 设置定时器初值自动装载 */
    TH1 = 0xf3;  /* 定时器初值设置 12MHz--通信波特率=2400 bps */
    TR1 = 1;
    TI = 1;
}

/**
 * @brief 主函数
 *
 * @return 退出码
 */
int main(void) {
    int led;
    serial_init();

    while (1) {
        puts("Hello. My school number is 20221303007");
        P1 = led;
        ++led;
        delay_ms(1000);
    }
}

/**
 * @brief 延时n毫秒
 *
 * @param ms 延时时间
 */
void delay_ms(int ms) {
    int i, j;
    for (i = 0; i < ms; ++i) {
        for (j = 0; j < 150; ++j)
            ;
    }
}
